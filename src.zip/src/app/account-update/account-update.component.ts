import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-account-update',
  templateUrl: './account-update.component.html',
  styleUrls: ['./account-update.component.css']
})
export class AccountUpdateComponent implements OnInit {

  userName = new FormControl('');
  password = new FormControl('');
  repeatPassword = new FormControl('');
  email = new FormControl('');
  constructor() { }

  ngOnInit() {
  }

}
