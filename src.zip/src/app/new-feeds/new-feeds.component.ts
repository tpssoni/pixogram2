import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-feeds',
  templateUrl: './new-feeds.component.html',
  styleUrls: ['./new-feeds.component.css']
})
export class NewFeedsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
