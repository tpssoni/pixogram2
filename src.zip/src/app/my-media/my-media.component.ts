import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-media',
  templateUrl: './my-media.component.html',
  styleUrls: ['./my-media.component.css']
})
export class MyMediaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
