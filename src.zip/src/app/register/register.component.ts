import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  userName = new FormControl('');
  password = new FormControl('');
  repeatPassword = new FormControl('');
  email = new FormControl('');
  
  constructor() { }

  ngOnInit() {
  }

}
