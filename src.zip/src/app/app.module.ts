import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { NavigationBarComponent } from './navigation-bar/navigation-bar.component';
import { LoginComponent } from './login/login.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { RegisterComponent } from './register/register.component';
import { AccountUpdateComponent } from './account-update/account-update.component';
import { BlockedAccountComponent } from './blocked-account/blocked-account.component';
import { FollowersComponent } from './followers/followers.component';
import { MultipleUploadMediaComponent } from './multiple-upload-media/multiple-upload-media.component';
import { MyMediaComponent } from './my-media/my-media.component';
import { NewFeedsComponent } from './new-feeds/new-feeds.component';
import { SearchComponent } from './search/search.component';

@NgModule({
  declarations: [
    AppComponent,
    NavigationBarComponent,
    LoginComponent,
    RegisterComponent,
    AccountUpdateComponent,
    BlockedAccountComponent,
    FollowersComponent,
    MultipleUploadMediaComponent,
    MyMediaComponent,
    NewFeedsComponent,
    SearchComponent,
  
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
